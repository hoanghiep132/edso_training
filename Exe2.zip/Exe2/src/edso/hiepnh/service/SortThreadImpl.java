package edso.hiepnh.service;

import edso.hiepnh.entities.MergeSort;
import edso.hiepnh.entities.MyArray;
import edso.hiepnh.entities.QuickSort;
import edso.hiepnh.entities.SortAlgorithm;

import java.util.ArrayList;
import java.util.List;

public class SortThreadImpl {

    private final int THREAD_LIMIT = 100;

    private int threadCount = 1;

    private MyArray myArray;

    public void setThreadCount(int threadCount) {
        if(threadCount > THREAD_LIMIT){
            this.threadCount = THREAD_LIMIT;
        }else if(threadCount < 0){
            this.threadCount = 1;
        }else{
            this.threadCount = threadCount;
        }
    }

    public MyArray getMyArray() {
        return myArray;
    }

    public void setMyArray(MyArray myArray) {
        this.myArray = myArray;
    }


    public void implement(){
        int range = myArray.getLength() / threadCount;
        List<Thread> threadList = new ArrayList<>();
        int i = 1;
        for(; i <= threadCount; i++){
            int begin = (i-1) * range;
            int end = myArray.getLength() < (i * range - 1) ? myArray.getLength() : (i * range - 1);
            Thread sortThread = new QuickSort(this.myArray.getArray(),begin,end);
            threadList.add(sortThread);
        }
        Thread sortThread = new QuickSort(this.myArray.getArray(),(i-1)*range,myArray.getLength()-1);
        threadList.add(sortThread);
        threadList.forEach(e -> {
            e.start();
            try {
                e.join();
            } catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
            }
        });
        if(threadCount > 1){
            merge(threadCount);
        }

    }

    public void merge(int numberOfThread){
        int range = myArray.getLength() / numberOfThread;
        int[] oldArray = myArray.getArray();
        int[] newArray = new int[myArray.getLength()];
        List<Thread> sortList = new ArrayList<>();
        for(int i = 0; i < numberOfThread;i += 2){
            int begin = i*range;
            int end = myArray.getLength() < (i+2)*range ? (myArray.getLength()-1) : (i+2)*range-1;
            Thread mergeSort = new QuickSort(oldArray,begin,end);
            sortList.add(mergeSort);
//            int begin1 = (i-1) * range;
//            int end1 = i * range - 1;
//            int begin2 = end1+1;
//            int end2 = (i+1) * range - 1;
//            int index = 0;
//            while (begin1 <= end1 && begin2 <= end2){
//                try{
//                    if(oldArray[begin1] < oldArray[begin2]){
//                        newArray[index++] = oldArray[begin1++];
//                    }else{
//                        newArray[index++] = oldArray[begin2++];
//                    }
//                }catch (Exception ex){
//                    System.err.println(begin1);
//                    break;
//                }
//            }
//            try{
//                while (begin1 <= end1){
//                    newArray[index++] = oldArray[begin1++];
//                }
//                while (begin2 <= end2){
//                    newArray[index++] = oldArray[begin2++];
//                }
//            }catch (Exception ex){
//                System.err.println(begin1 + "," + begin2);
//            }
        }
        for(Thread e : sortList) {
//        sortList.forEach(e -> {
            e.start();
            try {
                e.join();
            } catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
            }
        }
//        });
        if (numberOfThread >= 2){
            merge(numberOfThread/2);
        }
//        myArray.setArray(newArray);
    }
}
