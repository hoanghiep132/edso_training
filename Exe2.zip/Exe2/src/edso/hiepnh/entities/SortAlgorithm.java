package edso.hiepnh.entities;

public interface SortAlgorithm {
    void sort();

}
