package edso.hiepnh.main;

import edso.hiepnh.entities.MyArray;
import edso.hiepnh.entities.QuickSort;
import edso.hiepnh.entities.SortAlgorithm;
import edso.hiepnh.random.RandomArray;
import edso.hiepnh.service.SortThreadImpl;

public class Main {

    public static void main(String[] args) {
        int num = 100000;
        MyArray arr = new RandomArray().randomArray(num);

//        int[] array = arr.getArray();
//        arr.printArray();
//        System.out.println();
//        MyArray arr1 = new MyArray();
//        arr1.setArray(array);
//        arr1.setLength(num);
//
//        SortThreadImpl sortThread1 = new SortThreadImpl();
//        sortThread1.setMyArray(arr1);
//        sortThread1.setThreadCount(1);
//        long start1 = System.nanoTime();
//        sortThread1.implement();
//        long end1 = System.nanoTime();
//        arr.printArray();
//
//        System.out.println();
//        arr1.printArray();
//        System.out.println("\nTime  : " + (end1-start1)/1000000 + " ms\n\n");
//
//        MyArray arr2 = new MyArray(arr);
//        SortThreadImpl sortThread2 = new SortThreadImpl();
//        sortThread2.setMyArray(arr2);
//        sortThread2.setThreadCount(2);
//        long start2 = System.nanoTime();
//        sortThread2.implement();
//        long end2 = System.nanoTime();
////        arr.printArray();
//        System.out.println("\nTime  : " + (end2-start2)/1000000 + " ms\n\n");

        MyArray arr4 = new MyArray(arr);
        System.out.println("\n\n");
        SortThreadImpl sortThread4 = new SortThreadImpl();
        sortThread4.setMyArray(arr4);
        sortThread4.setThreadCount(4);
        long start4 = System.nanoTime();
        sortThread4.implement();
        long end4 = System.nanoTime();
        arr.printArray();
        System.out.println("\nTime  : " + (end4-start4)/1000000 + " ms\n\n");
    }
}
